public interface AI {
	public Board.Movement makeMove(Board b);
}
